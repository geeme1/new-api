package constant

var Setup = false
