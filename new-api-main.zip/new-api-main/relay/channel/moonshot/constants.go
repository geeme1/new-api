package moonshot

var ModelList = []string{
	"moonshot-v1-8k",
	"moonshot-v1-32k",
	"moonshot-v1-128k",
}

var ChannelName = "moonshot"
