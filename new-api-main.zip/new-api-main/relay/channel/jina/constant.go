package jina

var ModelList = []string{
	"jina-clip-v1",
	"jina-reranker-v2-base-multilingual",
	"jina-reranker-m0",
}

var ChannelName = "jina"
