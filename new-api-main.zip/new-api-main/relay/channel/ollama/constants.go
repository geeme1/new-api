package ollama

var ModelList = []string{
	"llama3-7b",
}

var ChannelName = "ollama"
