package xinference

var ModelList = []string{
	"bge-reranker-v2-m3",
	"jina-reranker-v2",
}

var ChannelName = "xinference"
