package deepseek

var ModelList = []string{
	"deepseek-chat", "deepseek-reasoner",
}

var ChannelName = "deepseek"
