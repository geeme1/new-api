package palm

var ModelList = []string{
	"PaLM-2",
}

var ChannelName = "google palm"
