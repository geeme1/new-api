package ali

var ModelList = []string{
	"wan2.5-i2v-preview", // 万相2.5 preview（有声视频）推荐
	"wan2.2-i2v-flash",   // 万相2.2极速版（无声视频）
	"wan2.2-i2v-plus",    // 万相2.2专业版（无声视频）
	"wanx2.1-i2v-plus",   // 万相2.1专业版（无声视频）
	"wanx2.1-i2v-turbo",  // 万相2.1极速版（无声视频）
}

var ChannelName = "ali"
